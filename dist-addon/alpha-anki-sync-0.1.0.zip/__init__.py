from __future__ import annotations

import json
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

from aqt import gui_hooks, mw
from aqt.qt import QAction
from aqt.utils import showInfo


ADDON_MODULE = __name__
SERVER: "SyncServer | None" = None


def _config() -> dict[str, Any]:
    config = mw.addonManager.getConfig(ADDON_MODULE) or {}
    if not config.get("token"):
        config["token"] = secrets.token_urlsafe(18)
        mw.addonManager.writeConfig(ADDON_MODULE, config)
    return config


def _run_on_main(function: Callable[[], Any], timeout: float = 20.0) -> Any:
    completed = threading.Event()
    result: dict[str, Any] = {}

    def invoke() -> None:
        try:
            result["value"] = function()
        except Exception as error:  # returned to the request thread
            result["error"] = error
        finally:
            completed.set()

    mw.taskman.run_on_main(invoke)
    if not completed.wait(timeout):
        raise TimeoutError("Anki main thread did not respond")
    if "error" in result:
        raise result["error"]
    return result.get("value")


def _lan_ip() -> str:
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 80))
        return str(probe.getsockname()[0])
    except OSError:
        return "<WindowsのIPアドレス>"
    finally:
        probe.close()


def _show_connection() -> None:
    config = _config()
    showInfo(
        "αnki PWA 同期\n\n"
        f"同期先: http://{_lan_ip()}:{int(config.get('port', 8766))}\n"
        f"ペアリングコード: {config['token']}\n\n"
        "iPhoneとこのPCを同じWi-Fiへ接続し、PWAの設定画面へ入力してください。"
    )


def _due_cards() -> list[dict[str, Any]]:
    if not mw.col:
        return []
    now = int(time.time() * 1000)
    card_ids = mw.col.find_cards("is:due")
    cards: list[dict[str, Any]] = []
    for card_id in card_ids:
        card = mw.col.get_card(card_id)
        note = card.note()
        deck_id = int(card.did)
        cards.append(
            {
                "id": int(card.id),
                "deckId": deck_id,
                "deckName": mw.col.decks.name(deck_id),
                "question": card.question(),
                "answer": card.answer(),
                "tags": list(note.tags),
                "dueAt": now,
                "updatedAt": int(getattr(card, "mod", int(time.time())) * 1000),
            }
        )
    return cards


def _apply_reviews(reviews: list[dict[str, Any]]) -> tuple[list[str], list[dict[str, str]]]:
    config = _config()
    applied = set(config.get("applied_review_ids", []))
    accepted: list[str] = []
    rejected: list[dict[str, str]] = []
    if not mw.col:
        return accepted, [{"id": str(item.get("id", "")), "reason": "Collection is not open"} for item in reviews]

    for review in sorted(reviews, key=lambda item: int(item.get("reviewedAt", 0))):
        event_id = str(review.get("id", ""))
        if not event_id:
            continue
        if event_id in applied:
            accepted.append(event_id)
            continue
        try:
            card_id = int(review["ankiCardId"])
            rating = int(review["rating"])
            if rating not in (1, 2, 3, 4):
                raise ValueError("Rating must be 1-4")
            card = mw.col.get_card(card_id)
            if not card or not card.id:
                raise ValueError("Card was deleted")
            # The scheduler remains the only writer of scheduling state. The
            # historical timestamp is preserved in the PWA event, while Anki
            # applies the transition at import time in this v0.1 protocol.
            mw.col.sched.answerCard(card, rating)
            applied.add(event_id)
            accepted.append(event_id)
        except Exception as error:
            rejected.append({"id": event_id, "reason": str(error)})

    config["applied_review_ids"] = list(applied)[-10000:]
    mw.addonManager.writeConfig(ADDON_MODULE, config)
    return accepted, rejected


class SyncHandler(BaseHTTPRequestHandler):
    server_version = "AlphaAnkiSync/0.1"

    def _origin(self) -> str:
        origin = self.headers.get("Origin", "*")
        allowed = _config().get("allowed_origins", ["*"])
        return origin if "*" in allowed or origin in allowed else "null"

    def _headers(self, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", self._origin())
        self.send_header("Access-Control-Allow-Headers", "authorization, content-type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        self._headers(status)
        self.wfile.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))

    def _authorized(self) -> bool:
        expected = f"Bearer {_config().get('token', '')}"
        return bool(expected != "Bearer " and secrets.compare_digest(self.headers.get("Authorization", ""), expected))

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._headers(204)

    def do_GET(self) -> None:  # noqa: N802
        if self.path != "/v1/status":
            self._json(404, {"error": "not_found"})
            return
        if not self._authorized():
            self._json(401, {"error": "unauthorized"})
            return
        self._json(200, {"ok": True, "ankiOpen": mw.col is not None, "serverTime": int(time.time() * 1000)})

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/v1/sync":
            self._json(404, {"error": "not_found"})
            return
        if not self._authorized():
            self._json(401, {"error": "unauthorized"})
            return
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 5_000_000)
            body = json.loads(self.rfile.read(length) or b"{}")
            reviews = body.get("reviews", [])
            if not isinstance(reviews, list):
                raise ValueError("reviews must be an array")
            accepted, rejected = _run_on_main(lambda: _apply_reviews(reviews))
            cards = _run_on_main(_due_cards)
            now = int(time.time() * 1000)
            self._json(200, {
                "cursor": str(now), "serverTime": now, "cards": cards,
                "deletedCardIds": [], "acceptedReviewIds": accepted, "rejectedReviews": rejected,
            })
        except Exception as error:
            self._json(500, {"error": "sync_failed", "message": str(error)})

    def log_message(self, format: str, *args: Any) -> None:
        return


class SyncServer:
    def __init__(self) -> None:
        config = _config()
        self.httpd = ThreadingHTTPServer((str(config.get("bind", "0.0.0.0")), int(config.get("port", 8766))), SyncHandler)
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="alpha-anki-sync", daemon=True)

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()


def _start_server() -> None:
    global SERVER
    if SERVER is not None:
        return
    try:
        SERVER = SyncServer()
        SERVER.start()
    except OSError as error:
        SERVER = None
        showInfo(f"αnki Syncを起動できませんでした。\n\n{error}")


def _stop_server() -> None:
    global SERVER
    if SERVER is not None:
        SERVER.stop()
        SERVER = None


action = QAction("αnki PWA 接続情報", mw)
action.triggered.connect(_show_connection)
mw.form.menuTools.addAction(action)
gui_hooks.profile_did_open.append(_start_server)
gui_hooks.profile_will_close.append(_stop_server)
